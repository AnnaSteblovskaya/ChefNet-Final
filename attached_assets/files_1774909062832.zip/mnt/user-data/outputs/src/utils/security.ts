/**
 * ChefNet Invest — Frontend Security Utilities
 * Защита на стороне клиента (React)
 * 
 * Файл: src/utils/security.ts
 */

// ═══════════════════════════════════════════════════════════════════════════════
// 1. XSS PROTECTION — Экранирование HTML
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Экранирование HTML-спецсимволов для предотвращения XSS
 * Использовать при выводе пользовательского контента
 */
export function escapeHtml(unsafe: string): string {
  return unsafe
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Очистка URL от javascript: и data: протоколов
 */
export function sanitizeUrl(url: string): string {
  const trimmed = url.trim().toLowerCase();
  if (
    trimmed.startsWith('javascript:') ||
    trimmed.startsWith('data:') ||
    trimmed.startsWith('vbscript:')
  ) {
    return '#';
  }
  return url;
}

/**
 * Очистка пользовательского ввода
 */
export function sanitizeInput(input: string): string {
  return input
    .replace(/[<>]/g, '') // удаляем HTML теги
    .replace(/javascript:/gi, '')
    .replace(/on\w+\s*=/gi, '')
    .trim();
}

// ═══════════════════════════════════════════════════════════════════════════════
// 2. SECURE TOKEN STORAGE — Безопасное хранение токенов
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * ВАЖНО: Refresh token хранится в httpOnly cookie (устанавливается сервером)
 * Access token храним только в памяти (не в localStorage!)
 */
class SecureTokenManager {
  private accessToken: string | null = null;
  private tokenExpiry: number = 0;
  private refreshPromise: Promise<string | null> | null = null;

  setAccessToken(token: string, expiresInSeconds: number = 900) {
    this.accessToken = token;
    this.tokenExpiry = Date.now() + expiresInSeconds * 1000;
  }

  getAccessToken(): string | null {
    if (!this.accessToken || Date.now() >= this.tokenExpiry) {
      this.accessToken = null;
      return null;
    }
    return this.accessToken;
  }

  isTokenExpired(): boolean {
    return !this.accessToken || Date.now() >= this.tokenExpiry - 30000; // 30 сек запас
  }

  clearTokens() {
    this.accessToken = null;
    this.tokenExpiry = 0;
  }

  /**
   * Автоматическое обновление токена
   * Использует дедупликацию — только один refresh запрос одновременно
   */
  async refreshAccessToken(): Promise<string | null> {
    if (this.refreshPromise) return this.refreshPromise;

    this.refreshPromise = (async () => {
      try {
        const response = await fetch('/api/auth/refresh', {
          method: 'POST',
          credentials: 'include', // включает httpOnly cookie
          headers: { 'Content-Type': 'application/json' },
        });

        if (!response.ok) {
          this.clearTokens();
          return null;
        }

        const data = await response.json();
        this.setAccessToken(data.accessToken, data.expiresIn);
        return data.accessToken;
      } catch {
        this.clearTokens();
        return null;
      } finally {
        this.refreshPromise = null;
      }
    })();

    return this.refreshPromise;
  }
}

export const tokenManager = new SecureTokenManager();

// ═══════════════════════════════════════════════════════════════════════════════
// 3. SECURE API CLIENT — Безопасный HTTP клиент
// ═══════════════════════════════════════════════════════════════════════════════

interface ApiOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  body?: any;
  headers?: Record<string, string>;
  skipAuth?: boolean;
}

let csrfToken: string | null = null;

/**
 * Получение CSRF токена
 */
async function getCsrfToken(): Promise<string> {
  if (csrfToken) return csrfToken;
  const response = await fetch('/api/csrf-token');
  const data = await response.json();
  csrfToken = data.csrfToken;
  return csrfToken!;
}

/**
 * Безопасный API запрос с автоматической авторизацией и CSRF
 */
export async function secureApiCall<T = any>(
  endpoint: string,
  options: ApiOptions = {}
): Promise<{ data: T | null; error: string | null; status: number }> {
  const { method = 'GET', body, headers = {}, skipAuth = false } = options;

  try {
    // 1. Проверяем и обновляем access token
    if (!skipAuth) {
      let token = tokenManager.getAccessToken();
      if (!token || tokenManager.isTokenExpired()) {
        token = await tokenManager.refreshAccessToken();
        if (!token) {
          return { data: null, error: 'Session expired. Please login again.', status: 401 };
        }
      }
      headers['Authorization'] = `Bearer ${token}`;
    }

    // 2. Добавляем CSRF токен для мутирующих запросов
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) {
      const csrf = await getCsrfToken();
      headers['X-CSRF-Token'] = csrf;
    }

    // 3. Выполняем запрос
    const response = await fetch(`/api${endpoint}`, {
      method,
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest',
        ...headers,
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    // 4. Обработка ответа
    if (response.status === 401 && !skipAuth) {
      // Токен протух — пробуем обновить один раз
      const newToken = await tokenManager.refreshAccessToken();
      if (newToken) {
        return secureApiCall(endpoint, { ...options, headers: {} });
      }
      tokenManager.clearTokens();
      // Перенаправляем на логин
      window.location.href = '/login';
      return { data: null, error: 'Unauthorized', status: 401 };
    }

    if (response.status === 429) {
      return { data: null, error: 'Too many requests. Please wait.', status: 429 };
    }

    const data = await response.json().catch(() => null);

    if (!response.ok) {
      return {
        data: null,
        error: data?.error || `Request failed with status ${response.status}`,
        status: response.status,
      };
    }

    return { data, error: null, status: response.status };
  } catch (error) {
    console.error('[API Error]', error);
    return { data: null, error: 'Network error. Please check your connection.', status: 0 };
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 4. CONTENT SECURITY — Безопасный рендеринг контента
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Безопасная вставка HTML (sanitized)
 * Использовать ВМЕСТО dangerouslySetInnerHTML
 */
export function createSafeMarkup(html: string): { __html: string } {
  // Удаляем все скрипты
  const cleaned = html
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, '')
    .replace(/<object\b[^<]*(?:(?!<\/object>)<[^<]*)*<\/object>/gi, '')
    .replace(/<embed\b[^>]*>/gi, '')
    .replace(/on\w+\s*=\s*["'][^"']*["']/gi, '') // event handlers
    .replace(/on\w+\s*=\s*[^\s>]*/gi, '') // event handlers without quotes
    .replace(/javascript:/gi, '')
    .replace(/vbscript:/gi, '')
    .replace(/data:text\/html/gi, '');

  return { __html: cleaned };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 5. FORM SECURITY — Безопасность форм
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Хук для защиты форм от автоматической отправки
 */
export function createFormProtection() {
  let lastSubmitTime = 0;
  const MIN_SUBMIT_INTERVAL = 2000; // минимум 2 секунды между отправками

  return {
    canSubmit: (): boolean => {
      const now = Date.now();
      if (now - lastSubmitTime < MIN_SUBMIT_INTERVAL) {
        return false;
      }
      lastSubmitTime = now;
      return true;
    },

    // Honeypot field — невидимое поле, которое боты заполняют
    isBot: (honeypotValue: string): boolean => {
      return honeypotValue.length > 0;
    },
  };
}

/**
 * Валидация email на клиенте
 */
export function isValidEmail(email: string): boolean {
  const re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  return re.test(email) && email.length <= 255;
}

/**
 * Маскировка чувствительных данных
 */
export function maskEmail(email: string): string {
  const [local, domain] = email.split('@');
  if (local.length <= 2) return `${local[0]}***@${domain}`;
  return `${local[0]}${local[1]}***@${domain}`;
}

export function maskPhone(phone: string): string {
  if (phone.length < 7) return '***';
  return phone.slice(0, 3) + '***' + phone.slice(-2);
}

// ═══════════════════════════════════════════════════════════════════════════════
// 6. ERROR HANDLING — Безопасная обработка ошибок
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Безопасное отображение ошибок (без утечки серверных деталей)
 */
export function getSafeErrorMessage(error: any): string {
  if (typeof error === 'string') return error;
  if (error?.error) return String(error.error);
  if (error?.message) {
    // Скрываем технические детали
    const msg = String(error.message);
    if (msg.includes('ECONNREFUSED') || msg.includes('ETIMEDOUT')) {
      return 'Service temporarily unavailable. Please try again later.';
    }
    if (msg.includes('SQL') || msg.includes('query') || msg.includes('relation')) {
      return 'An internal error occurred. Please contact support.';
    }
    return msg;
  }
  return 'An unexpected error occurred. Please try again.';
}
