/**
 * ChefNet Invest — Security Middleware
 * Полный комплект защиты Express-сервера
 * 
 * Установка зависимостей:
 * npm install helmet express-rate-limit express-slow-down hpp express-mongo-sanitize xss-clean cors
 * npm install -D @types/hpp
 */

import { Request, Response, NextFunction } from 'express';

// ═══════════════════════════════════════════════════════════════════════════════
// 1. HELMET — HTTP Security Headers
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Конфигурация Helmet для установки защитных HTTP-заголовков
 * Применять: app.use(helmetConfig())
 */
export function helmetConfig() {
  // Динамический импорт т.к. helmet — ESM
  const helmet = require('helmet');
  return helmet({
    // Content-Security-Policy — защита от XSS и инъекций
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: [
          "'self'",
          "'unsafe-inline'", // нужно для React, но лучше заменить на nonce
          "https://www.google.com",
          "https://www.gstatic.com", // reCAPTCHA
        ],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        imgSrc: ["'self'", "data:", "blob:", "https://*.supabase.co"],
        connectSrc: [
          "'self'",
          "https://*.supabase.co",
          "wss://*.supabase.co",
          "https://api.sumsub.com",
        ],
        frameSrc: ["https://www.google.com"], // reCAPTCHA iframe
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
        frameAncestors: ["'self'"], // заменяет X-Frame-Options
        upgradeInsecureRequests: [],
      },
    },
    // Дополнительные заголовки
    crossOriginEmbedderPolicy: false, // отключаем для Supabase
    crossOriginOpenerPolicy: { policy: "same-origin" },
    crossOriginResourcePolicy: { policy: "cross-origin" },
    dnsPrefetchControl: { allow: false },
    hsts: { maxAge: 31536000, includeSubDomains: true, preload: true },
    referrerPolicy: { policy: "strict-origin-when-cross-origin" },
    xContentTypeOptions: true, // X-Content-Type-Options: nosniff
    xFrameOptions: { action: "sameorigin" },
  });
}

// ═══════════════════════════════════════════════════════════════════════════════
// 2. RATE LIMITING — Защита от brute-force и DDoS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Общий rate limiter для всех API запросов
 */
export function createGeneralRateLimiter() {
  const rateLimit = require('express-rate-limit');
  return rateLimit({
    windowMs: 15 * 60 * 1000, // 15 минут
    max: 100, // макс 100 запросов с одного IP за 15 мин
    standardHeaders: true,
    legacyHeaders: false,
    message: {
      error: 'Too many requests, please try again later.',
      retryAfter: 15,
    },
    keyGenerator: (req: Request) => {
      return req.headers['x-forwarded-for'] as string || req.ip || 'unknown';
    },
  });
}

/**
 * Строгий rate limiter для аутентификации (login, register, password reset)
 */
export function createAuthRateLimiter() {
  const rateLimit = require('express-rate-limit');
  return rateLimit({
    windowMs: 15 * 60 * 1000, // 15 минут
    max: 5, // макс 5 попыток за 15 мин
    standardHeaders: true,
    legacyHeaders: false,
    message: {
      error: 'Too many authentication attempts. Please wait 15 minutes.',
    },
    skipSuccessfulRequests: true, // не считать успешные попытки
  });
}

/**
 * Rate limiter для API ключей / чувствительных endpoints
 */
export function createStrictRateLimiter() {
  const rateLimit = require('express-rate-limit');
  return rateLimit({
    windowMs: 60 * 60 * 1000, // 1 час
    max: 10,
    message: {
      error: 'Rate limit exceeded for this sensitive endpoint.',
    },
  });
}

/**
 * Slow-down middleware — замедляет ответы при частых запросах
 */
export function createSlowDown() {
  const slowDown = require('express-slow-down');
  return slowDown({
    windowMs: 15 * 60 * 1000,
    delayAfter: 50, // начинать замедление после 50 запросов
    delayMs: (hits: number) => (hits - 50) * 200, // +200мс за каждый следующий
    maxDelayMs: 5000,
  });
}

// ═══════════════════════════════════════════════════════════════════════════════
// 3. CORS — Cross-Origin Resource Sharing
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Строгая CORS конфигурация
 */
export function createCorsConfig() {
  const cors = require('cors');

  const allowedOrigins = [
    'https://chefnet.ai',
    'https://www.chefnet.ai',
    'https://chefnet.replit.app',
  ];

  // В development разрешаем localhost
  if (process.env.NODE_ENV !== 'production') {
    allowedOrigins.push('http://localhost:5000', 'http://localhost:3001');
  }

  return cors({
    origin: (origin: string | undefined, callback: Function) => {
      // Разрешить запросы без origin (мобильные приложения, curl)
      if (!origin) return callback(null, true);
      if (allowedOrigins.includes(origin)) {
        return callback(null, true);
      }
      return callback(new Error('Not allowed by CORS'));
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'X-CSRF-Token'],
    exposedHeaders: ['X-RateLimit-Limit', 'X-RateLimit-Remaining'],
    maxAge: 86400, // кэшировать preflight на 24 часа
  });
}

// ═══════════════════════════════════════════════════════════════════════════════
// 4. INPUT SANITIZATION — Защита от инъекций
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Очистка входных данных от XSS, SQL injection, NoSQL injection
 */
export function sanitizeInput(req: Request, _res: Response, next: NextFunction) {
  const sanitize = (obj: any): any => {
    if (typeof obj === 'string') {
      return obj
        .replace(/[<>]/g, '') // убираем HTML теги
        .replace(/javascript:/gi, '') // убираем javascript: URI
        .replace(/on\w+\s*=/gi, '') // убираем event handlers
        .replace(/\$(?:gt|gte|lt|lte|ne|in|nin|regex|exists|type|mod|where|all|size|elemMatch|slice|not|nor|or|and)\b/gi, '') // MongoDB operators
        .trim();
    }
    if (Array.isArray(obj)) {
      return obj.map(sanitize);
    }
    if (obj && typeof obj === 'object') {
      const cleaned: Record<string, any> = {};
      for (const [key, value] of Object.entries(obj)) {
        // Блокируем ключи, начинающиеся с $ (NoSQL injection)
        if (key.startsWith('$')) continue;
        // Блокируем __proto__ pollution
        if (key === '__proto__' || key === 'constructor' || key === 'prototype') continue;
        cleaned[key] = sanitize(value);
      }
      return cleaned;
    }
    return obj;
  };

  if (req.body) req.body = sanitize(req.body);
  if (req.query) req.query = sanitize(req.query) as any;
  if (req.params) req.params = sanitize(req.params);

  next();
}

/**
 * Защита от HTTP Parameter Pollution
 */
export function hppProtection() {
  const hpp = require('hpp');
  return hpp({
    whitelist: ['sort', 'fields', 'page', 'limit', 'lang'], // разрешённые дублирующиеся параметры
  });
}

// ═══════════════════════════════════════════════════════════════════════════════
// 5. REQUEST VALIDATION — Валидация запросов
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Ограничение размера body
 */
export function bodyLimits() {
  const express = require('express');
  return [
    express.json({ limit: '1mb' }), // JSON body max 1MB
    express.urlencoded({ extended: true, limit: '1mb' }),
  ];
}

/**
 * Блокировка подозрительных User-Agent
 */
export function blockSuspiciousUserAgents(req: Request, res: Response, next: NextFunction) {
  const ua = req.headers['user-agent'] || '';
  const blocked = [
    /sqlmap/i,
    /nikto/i,
    /nmap/i,
    /masscan/i,
    /dirbuster/i,
    /gobuster/i,
    /wfuzz/i,
    /hydra/i,
    /burpsuite/i,
    /nessus/i,
    /openvas/i,
    /w3af/i,
  ];

  if (blocked.some(pattern => pattern.test(ua))) {
    return res.status(403).json({ error: 'Access denied' });
  }
  next();
}

/**
 * Блокировка опасных путей (path traversal, scanner probes)
 */
export function blockDangerousPaths(req: Request, res: Response, next: NextFunction) {
  const path = req.path.toLowerCase();
  const blockedPaths = [
    '/wp-admin', '/wp-login', '/wp-content',  // WordPress сканеры
    '/phpmyadmin', '/pma',                      // phpMyAdmin
    '/.env', '/.git', '/.svn',                  // конфиг файлы
    '/admin/config', '/debug',                   // debug endpoints
    '/actuator', '/jolokia',                     // Java management
    '/console', '/shell',                        // shell access
    '/cgi-bin', '/scripts',                      // CGI
    '/../', '/..\\',                             // path traversal
  ];

  if (blockedPaths.some(p => path.includes(p))) {
    console.warn(`[SECURITY] Blocked suspicious path: ${req.ip} → ${req.path}`);
    return res.status(404).json({ error: 'Not found' });
  }

  // Блокировка path traversal
  if (path.includes('..') || path.includes('%2e%2e') || path.includes('%252e')) {
    console.warn(`[SECURITY] Path traversal attempt: ${req.ip} → ${req.path}`);
    return res.status(400).json({ error: 'Invalid path' });
  }

  next();
}

// ═══════════════════════════════════════════════════════════════════════════════
// 6. SECURITY LOGGING — Логирование атак
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Логирование подозрительной активности
 */
export function securityLogger(req: Request, _res: Response, next: NextFunction) {
  const suspicious = [
    /union\s+select/i,
    /insert\s+into/i,
    /drop\s+table/i,
    /delete\s+from/i,
    /update\s+.*set/i,
    /<script/i,
    /eval\s*\(/i,
    /exec\s*\(/i,
    /xp_cmdshell/i,
  ];

  const fullUrl = req.originalUrl;
  const body = JSON.stringify(req.body || {});

  for (const pattern of suspicious) {
    if (pattern.test(fullUrl) || pattern.test(body)) {
      console.error(`[SECURITY ALERT] Suspicious request detected:
  IP: ${req.headers['x-forwarded-for'] || req.ip}
  Method: ${req.method}
  Path: ${req.originalUrl}
  User-Agent: ${req.headers['user-agent']}
  Time: ${new Date().toISOString()}
`);
      break;
    }
  }

  next();
}

// ═══════════════════════════════════════════════════════════════════════════════
// 7. CSRF PROTECTION — Cross-Site Request Forgery
// ═══════════════════════════════════════════════════════════════════════════════

import crypto from 'crypto';

const csrfTokens = new Map<string, { token: string; expires: number }>();

/**
 * Генерация CSRF токена
 */
export function generateCsrfToken(req: Request, res: Response) {
  const token = crypto.randomBytes(32).toString('hex');
  const sessionId = req.headers['authorization'] || req.ip || 'anonymous';

  csrfTokens.set(String(sessionId), {
    token,
    expires: Date.now() + 3600000, // 1 час
  });

  // Очистка просроченных токенов
  for (const [key, value] of csrfTokens.entries()) {
    if (value.expires < Date.now()) csrfTokens.delete(key);
  }

  res.json({ csrfToken: token });
}

/**
 * Валидация CSRF токена
 */
export function validateCsrf(req: Request, res: Response, next: NextFunction) {
  // Пропускаем GET, HEAD, OPTIONS
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();

  const token = req.headers['x-csrf-token'] as string;
  const sessionId = req.headers['authorization'] || req.ip || 'anonymous';
  const stored = csrfTokens.get(String(sessionId));

  if (!stored || stored.token !== token || stored.expires < Date.now()) {
    return res.status(403).json({ error: 'Invalid or expired CSRF token' });
  }

  next();
}

// ═══════════════════════════════════════════════════════════════════════════════
// 8. APPLY ALL — Единая функция применения всей защиты
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Применить всю защиту к Express приложению
 * 
 * Использование:
 * import { applySecurityMiddleware } from './middleware/security';
 * applySecurityMiddleware(app);
 */
export function applySecurityMiddleware(app: any) {
  // 1. Базовые заголовки безопасности
  app.use(helmetConfig());

  // 2. CORS
  app.use(createCorsConfig());

  // 3. Rate limiting
  app.use('/api/', createGeneralRateLimiter());
  app.use('/api/auth/', createAuthRateLimiter());
  app.use('/api/admin/', createStrictRateLimiter());

  // 4. Slow down
  app.use(createSlowDown());

  // 5. Body parsing с лимитами
  for (const parser of bodyLimits()) {
    app.use(parser);
  }

  // 6. HPP protection
  app.use(hppProtection());

  // 7. Input sanitization
  app.use(sanitizeInput);

  // 8. Block scanners & dangerous paths
  app.use(blockSuspiciousUserAgents);
  app.use(blockDangerousPaths);

  // 9. Security logging
  app.use(securityLogger);

  // 10. CSRF endpoint
  app.get('/api/csrf-token', generateCsrfToken);

  // 11. Отключаем раскрытие технологий
  app.disable('x-powered-by');

  // 12. Защита от clickjacking в ответах
  app.use((_req: Request, res: Response, next: NextFunction) => {
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
    next();
  });

  console.log('[SECURITY] All middleware applied successfully');
}
