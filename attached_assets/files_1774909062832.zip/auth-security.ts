/**
 * ChefNet Invest — Authentication & Session Security
 * JWT токены, сессии, хеширование паролей
 * 
 * Установка: npm install jsonwebtoken bcryptjs cookie-parser
 * npm install -D @types/jsonwebtoken @types/bcryptjs @types/cookie-parser
 */

import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';

// ═══════════════════════════════════════════════════════════════════════════════
// 1. PASSWORD SECURITY — Хеширование и валидация паролей
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Хеширование пароля с bcrypt
 */
export async function hashPassword(password: string): Promise<string> {
  const bcrypt = require('bcryptjs');
  const salt = await bcrypt.genSalt(12); // 12 раундов — баланс безопасности и скорости
  return bcrypt.hash(password, salt);
}

/**
 * Проверка пароля
 */
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  const bcrypt = require('bcryptjs');
  return bcrypt.compare(password, hash);
}

/**
 * Валидация сложности пароля
 */
export function validatePasswordStrength(password: string): {
  valid: boolean;
  errors: string[];
} {
  const errors: string[] = [];

  if (password.length < 8) errors.push('Password must be at least 8 characters');
  if (password.length > 128) errors.push('Password must not exceed 128 characters');
  if (!/[A-Z]/.test(password)) errors.push('Password must contain an uppercase letter');
  if (!/[a-z]/.test(password)) errors.push('Password must contain a lowercase letter');
  if (!/[0-9]/.test(password)) errors.push('Password must contain a number');
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)) {
    errors.push('Password must contain a special character');
  }

  // Проверка на распространённые пароли
  const commonPasswords = [
    'password', '12345678', 'qwerty', 'abc123', 'letmein',
    'admin', 'welcome', 'monkey', 'master', 'dragon',
    'login', 'princess', 'football', 'shadow', 'sunshine',
    'trustno1', 'iloveyou', 'batman', 'access', 'hello',
    'charlie', 'password1', 'Password1', 'chefnet',
  ];

  if (commonPasswords.includes(password.toLowerCase())) {
    errors.push('This password is too common');
  }

  return { valid: errors.length === 0, errors };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 2. JWT TOKEN MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════════════

const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(64).toString('hex');
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || crypto.randomBytes(64).toString('hex');

interface TokenPayload {
  userId: string;
  email: string;
  role: 'user' | 'admin' | 'investor';
  sessionId: string;
}

/**
 * Генерация пары токенов (access + refresh)
 */
export function generateTokenPair(payload: Omit<TokenPayload, 'sessionId'>): {
  accessToken: string;
  refreshToken: string;
  sessionId: string;
} {
  const jwt = require('jsonwebtoken');
  const sessionId = crypto.randomUUID();

  const tokenPayload: TokenPayload = { ...payload, sessionId };

  const accessToken = jwt.sign(tokenPayload, JWT_SECRET, {
    expiresIn: '15m', // Access token — 15 минут
    issuer: 'chefnet-invest',
    audience: 'chefnet-web',
  });

  const refreshToken = jwt.sign(
    { userId: payload.userId, sessionId },
    JWT_REFRESH_SECRET,
    {
      expiresIn: '7d', // Refresh token — 7 дней
      issuer: 'chefnet-invest',
      audience: 'chefnet-web',
    }
  );

  return { accessToken, refreshToken, sessionId };
}

/**
 * Верификация access token
 */
export function verifyAccessToken(token: string): TokenPayload | null {
  const jwt = require('jsonwebtoken');
  try {
    return jwt.verify(token, JWT_SECRET, {
      issuer: 'chefnet-invest',
      audience: 'chefnet-web',
    }) as TokenPayload;
  } catch {
    return null;
  }
}

/**
 * Верификация refresh token
 */
export function verifyRefreshToken(token: string): { userId: string; sessionId: string } | null {
  const jwt = require('jsonwebtoken');
  try {
    return jwt.verify(token, JWT_REFRESH_SECRET, {
      issuer: 'chefnet-invest',
      audience: 'chefnet-web',
    }) as { userId: string; sessionId: string };
  } catch {
    return null;
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 3. AUTH MIDDLEWARE — Защита маршрутов
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Middleware: требует аутентификацию
 */
export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const token = authHeader.split(' ')[1];
  const payload = verifyAccessToken(token);

  if (!payload) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }

  // Добавляем данные пользователя в request
  (req as any).user = payload;
  next();
}

/**
 * Middleware: требует определённую роль
 */
export function requireRole(...roles: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    const user = (req as any).user;
    if (!user) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    if (!roles.includes(user.role)) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
  };
}

/**
 * Middleware: владелец ресурса или admin
 */
export function requireOwnerOrAdmin(userIdParam: string = 'userId') {
  return (req: Request, res: Response, next: NextFunction) => {
    const user = (req as any).user;
    const resourceUserId = req.params[userIdParam] || req.body[userIdParam];

    if (!user) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    if (user.role === 'admin' || user.userId === resourceUserId) {
      return next();
    }
    return res.status(403).json({ error: 'Access denied' });
  };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 4. SESSION MANAGEMENT — Управление сессиями
// ═══════════════════════════════════════════════════════════════════════════════

// Хранилище активных сессий (в продакшене — Redis)
const activeSessions = new Map<string, {
  userId: string;
  createdAt: number;
  lastActivity: number;
  ip: string;
  userAgent: string;
}>();

/**
 * Регистрация новой сессии
 */
export function registerSession(
  sessionId: string,
  userId: string,
  ip: string,
  userAgent: string
) {
  // Ограничение: макс 5 активных сессий на пользователя
  const userSessions = [...activeSessions.entries()]
    .filter(([, s]) => s.userId === userId);

  if (userSessions.length >= 5) {
    // Удаляем самую старую сессию
    const oldest = userSessions.sort((a, b) => a[1].lastActivity - b[1].lastActivity)[0];
    activeSessions.delete(oldest[0]);
  }

  activeSessions.set(sessionId, {
    userId,
    createdAt: Date.now(),
    lastActivity: Date.now(),
    ip,
    userAgent,
  });
}

/**
 * Проверка валидности сессии
 */
export function isSessionValid(sessionId: string): boolean {
  const session = activeSessions.get(sessionId);
  if (!session) return false;

  // Сессия истекает через 24 часа неактивности
  if (Date.now() - session.lastActivity > 24 * 60 * 60 * 1000) {
    activeSessions.delete(sessionId);
    return false;
  }

  session.lastActivity = Date.now();
  return true;
}

/**
 * Инвалидация сессии (logout)
 */
export function invalidateSession(sessionId: string) {
  activeSessions.delete(sessionId);
}

/**
 * Инвалидация всех сессий пользователя (смена пароля, компрометация)
 */
export function invalidateAllUserSessions(userId: string) {
  for (const [id, session] of activeSessions.entries()) {
    if (session.userId === userId) {
      activeSessions.delete(id);
    }
  }
}

/**
 * Получение списка активных сессий пользователя
 */
export function getUserSessions(userId: string) {
  return [...activeSessions.entries()]
    .filter(([, s]) => s.userId === userId)
    .map(([id, s]) => ({
      sessionId: id,
      ip: s.ip,
      userAgent: s.userAgent,
      createdAt: new Date(s.createdAt).toISOString(),
      lastActivity: new Date(s.lastActivity).toISOString(),
    }));
}

// ═══════════════════════════════════════════════════════════════════════════════
// 5. BRUTE FORCE PROTECTION — Защита от перебора
// ═══════════════════════════════════════════════════════════════════════════════

const loginAttempts = new Map<string, { count: number; lastAttempt: number; lockedUntil: number }>();

/**
 * Проверка и регистрация попытки входа
 * Возвращает true если вход разрешён
 */
export function checkLoginAttempt(identifier: string): {
  allowed: boolean;
  remainingAttempts: number;
  lockedUntil?: string;
} {
  const now = Date.now();
  const record = loginAttempts.get(identifier);

  if (!record) {
    loginAttempts.set(identifier, { count: 1, lastAttempt: now, lockedUntil: 0 });
    return { allowed: true, remainingAttempts: 4 };
  }

  // Проверка блокировки
  if (record.lockedUntil > now) {
    return {
      allowed: false,
      remainingAttempts: 0,
      lockedUntil: new Date(record.lockedUntil).toISOString(),
    };
  }

  // Сброс счётчика если прошло больше 15 минут
  if (now - record.lastAttempt > 15 * 60 * 1000) {
    record.count = 0;
  }

  record.count++;
  record.lastAttempt = now;

  // Прогрессивная блокировка
  if (record.count >= 5) {
    const lockDuration = Math.min(record.count * 5 * 60 * 1000, 60 * 60 * 1000); // макс 1 час
    record.lockedUntil = now + lockDuration;
    return {
      allowed: false,
      remainingAttempts: 0,
      lockedUntil: new Date(record.lockedUntil).toISOString(),
    };
  }

  return { allowed: true, remainingAttempts: 5 - record.count };
}

/**
 * Сброс счётчика после успешного входа
 */
export function resetLoginAttempts(identifier: string) {
  loginAttempts.delete(identifier);
}

// ═══════════════════════════════════════════════════════════════════════════════
// 6. SECURE COOKIES — Безопасные куки
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Установка refresh token в httpOnly cookie
 */
export function setRefreshTokenCookie(res: Response, refreshToken: string) {
  res.cookie('refreshToken', refreshToken, {
    httpOnly: true,      // недоступен из JavaScript
    secure: process.env.NODE_ENV === 'production', // только HTTPS
    sameSite: 'strict',  // защита от CSRF
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 дней
    path: '/api/auth/refresh', // только для refresh endpoint
    domain: process.env.NODE_ENV === 'production' ? '.chefnet.ai' : undefined,
  });
}

/**
 * Очистка refresh token cookie
 */
export function clearRefreshTokenCookie(res: Response) {
  res.clearCookie('refreshToken', {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    path: '/api/auth/refresh',
  });
}
