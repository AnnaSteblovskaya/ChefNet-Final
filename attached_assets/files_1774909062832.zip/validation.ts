/**
 * ChefNet Invest — Input Validation Schemas
 * Валидация всех входных данных с помощью Zod
 * 
 * Установка: npm install zod
 */

import { Request, Response, NextFunction } from 'express';

// Используем Zod для типобезопасной валидации
const z = require('zod');

// ═══════════════════════════════════════════════════════════════════════════════
// 1. COMMON SCHEMAS — Общие схемы
// ═══════════════════════════════════════════════════════════════════════════════

export const emailSchema = z
  .string()
  .email('Invalid email format')
  .max(255)
  .transform((e: string) => e.toLowerCase().trim());

export const passwordSchema = z
  .string()
  .min(8, 'Password must be at least 8 characters')
  .max(128, 'Password too long')
  .regex(/[A-Z]/, 'Must contain uppercase letter')
  .regex(/[a-z]/, 'Must contain lowercase letter')
  .regex(/[0-9]/, 'Must contain number')
  .regex(/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/, 'Must contain special character');

export const uuidSchema = z.string().uuid('Invalid ID format');

export const paginationSchema = z.object({
  page: z.coerce.number().int().min(1).max(1000).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  sort: z.string().max(50).optional(),
  order: z.enum(['asc', 'desc']).default('desc'),
});

// ═══════════════════════════════════════════════════════════════════════════════
// 2. AUTH SCHEMAS — Аутентификация
// ═══════════════════════════════════════════════════════════════════════════════

export const registerSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
  firstName: z.string().min(1).max(100).regex(/^[a-zA-Zа-яА-ЯёЁüöäÜÖÄßçşğıİ\s\-']+$/, 'Invalid characters in name'),
  lastName: z.string().min(1).max(100).regex(/^[a-zA-Zа-яА-ЯёЁüöäÜÖÄßçşğıİ\s\-']+$/, 'Invalid characters in name'),
  phone: z.string().max(20).regex(/^\+?[0-9\s\-()]+$/, 'Invalid phone format').optional(),
  referralCode: z.string().max(50).optional(),
  recaptchaToken: z.string().min(1, 'reCAPTCHA is required'),
  language: z.enum(['en', 'ru', 'es', 'tr']).default('en'),
});

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1).max(128),
  recaptchaToken: z.string().min(1, 'reCAPTCHA is required'),
  rememberMe: z.boolean().optional().default(false),
});

export const resetPasswordSchema = z.object({
  email: emailSchema,
  recaptchaToken: z.string().min(1, 'reCAPTCHA is required'),
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: passwordSchema,
}).refine(
  (data: { currentPassword: string; newPassword: string }) => data.currentPassword !== data.newPassword,
  { message: 'New password must be different from current', path: ['newPassword'] }
);

export const verifyEmailSchema = z.object({
  token: z.string().min(10).max(500),
});

// ═══════════════════════════════════════════════════════════════════════════════
// 3. INVESTMENT SCHEMAS — Инвестиции
// ═══════════════════════════════════════════════════════════════════════════════

export const createInvestmentSchema = z.object({
  amount: z.number()
    .positive('Amount must be positive')
    .min(100, 'Minimum investment is $100')
    .max(10000000, 'Maximum investment is $10,000,000'),
  projectId: uuidSchema,
  currency: z.enum(['USD', 'EUR', 'GBP']).default('USD'),
  notes: z.string().max(1000).optional(),
});

export const updateInvestmentSchema = z.object({
  status: z.enum(['pending', 'confirmed', 'cancelled', 'refunded']),
  notes: z.string().max(1000).optional(),
});

// ═══════════════════════════════════════════════════════════════════════════════
// 4. PROFILE SCHEMAS — Профиль пользователя
// ═══════════════════════════════════════════════════════════════════════════════

export const updateProfileSchema = z.object({
  firstName: z.string().min(1).max(100).regex(/^[a-zA-Zа-яА-ЯёЁüöäÜÖÄßçşğıİ\s\-']+$/).optional(),
  lastName: z.string().min(1).max(100).regex(/^[a-zA-Zа-яА-ЯёЁüöäÜÖÄßçşğıİ\s\-']+$/).optional(),
  phone: z.string().max(20).regex(/^\+?[0-9\s\-()]+$/).optional(),
  country: z.string().max(100).optional(),
  city: z.string().max(100).optional(),
  language: z.enum(['en', 'ru', 'es', 'tr']).optional(),
  avatarUrl: z.string().url().max(500).optional(),
});

// ═══════════════════════════════════════════════════════════════════════════════
// 5. ADMIN SCHEMAS — Администрирование
// ═══════════════════════════════════════════════════════════════════════════════

export const adminUpdateUserSchema = z.object({
  role: z.enum(['user', 'investor', 'admin']).optional(),
  isVerified: z.boolean().optional(),
  isBlocked: z.boolean().optional(),
  kycStatus: z.enum(['none', 'pending', 'approved', 'rejected']).optional(),
  notes: z.string().max(2000).optional(),
});

export const adminSearchSchema = z.object({
  query: z.string().max(200).optional(),
  role: z.enum(['user', 'investor', 'admin', 'all']).default('all'),
  status: z.enum(['active', 'blocked', 'unverified', 'all']).default('all'),
  ...paginationSchema.shape,
});

// ═══════════════════════════════════════════════════════════════════════════════
// 6. FILE UPLOAD SCHEMAS — Загрузка файлов
// ═══════════════════════════════════════════════════════════════════════════════

export const allowedMimeTypes = [
  'image/jpeg',
  'image/png',
  'image/webp',
  'application/pdf',
] as const;

export const maxFileSize = 10 * 1024 * 1024; // 10MB

export function validateFileUpload(file: Express.Multer.File): {
  valid: boolean;
  error?: string;
} {
  if (!file) return { valid: false, error: 'No file provided' };

  if (!allowedMimeTypes.includes(file.mimetype as any)) {
    return { valid: false, error: `File type ${file.mimetype} is not allowed` };
  }

  if (file.size > maxFileSize) {
    return { valid: false, error: `File size exceeds ${maxFileSize / 1024 / 1024}MB limit` };
  }

  // Проверка magic bytes (реальный тип файла)
  const magicBytes: Record<string, number[]> = {
    'image/jpeg': [0xFF, 0xD8, 0xFF],
    'image/png': [0x89, 0x50, 0x4E, 0x47],
    'application/pdf': [0x25, 0x50, 0x44, 0x46],
  };

  const buffer = file.buffer;
  if (buffer && magicBytes[file.mimetype]) {
    const expected = magicBytes[file.mimetype];
    const actual = Array.from(buffer.slice(0, expected.length));
    if (!expected.every((byte, i) => byte === actual[i])) {
      return { valid: false, error: 'File content does not match declared type' };
    }
  }

  // Проверка имени файла
  const safeName = file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
  if (safeName.includes('..') || safeName.startsWith('.')) {
    return { valid: false, error: 'Invalid filename' };
  }

  return { valid: true };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 7. VALIDATION MIDDLEWARE — Универсальный middleware для валидации
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Middleware: валидация body по Zod-схеме
 * 
 * Использование:
 * router.post('/register', validate(registerSchema), registerHandler);
 */
export function validate(schema: any) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = schema.safeParse(req.body);
      if (!result.success) {
        const errors = result.error.issues.map((issue: any) => ({
          field: issue.path.join('.'),
          message: issue.message,
        }));
        return res.status(400).json({
          error: 'Validation failed',
          details: errors,
        });
      }
      // Заменяем body на валидированные и трансформированные данные
      req.body = result.data;
      next();
    } catch (error) {
      return res.status(400).json({ error: 'Invalid request data' });
    }
  };
}

/**
 * Middleware: валидация query параметров
 */
export function validateQuery(schema: any) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = schema.safeParse(req.query);
      if (!result.success) {
        return res.status(400).json({
          error: 'Invalid query parameters',
          details: result.error.issues,
        });
      }
      req.query = result.data;
      next();
    } catch {
      return res.status(400).json({ error: 'Invalid query parameters' });
    }
  };
}

/**
 * Middleware: валидация URL параметров
 */
export function validateParams(schema: any) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = schema.safeParse(req.params);
      if (!result.success) {
        return res.status(400).json({
          error: 'Invalid URL parameters',
          details: result.error.issues,
        });
      }
      req.params = result.data;
      next();
    } catch {
      return res.status(400).json({ error: 'Invalid parameters' });
    }
  };
}
