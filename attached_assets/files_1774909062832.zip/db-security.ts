/**
 * ChefNet Invest — Database Security
 * Защита PostgreSQL от SQL Injection, Row Level Security
 * 
 * Этот файл содержит:
 * 1. Безопасные query builders
 * 2. SQL миграции для Row Level Security
 * 3. Database audit logging
 */

// ═══════════════════════════════════════════════════════════════════════════════
// 1. SAFE QUERY BUILDER — Параметризованные запросы
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * НИКОГДА не используйте интерполяцию строк в SQL запросах!
 * 
 * ❌ ОПАСНО:
 * db.query(`SELECT * FROM users WHERE email = '${email}'`)
 * 
 * ✅ БЕЗОПАСНО:
 * db.query('SELECT * FROM users WHERE email = $1', [email])
 */

interface QueryConfig {
  text: string;
  values: any[];
}

/**
 * Безопасный построитель SELECT запросов
 */
export function safeSelect(
  table: string,
  columns: string[],
  conditions: Record<string, any>,
  options?: { limit?: number; offset?: number; orderBy?: string; order?: 'ASC' | 'DESC' }
): QueryConfig {
  // Валидация имени таблицы (только буквы, цифры, подчёркивание)
  if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(table)) {
    throw new Error('Invalid table name');
  }

  // Валидация имён колонок
  const safeColumns = columns.map(col => {
    if (!/^[a-zA-Z_][a-zA-Z0-9_.]*$/.test(col)) {
      throw new Error(`Invalid column name: ${col}`);
    }
    return `"${col}"`;
  });

  const values: any[] = [];
  const whereParts: string[] = [];

  for (const [key, value] of Object.entries(conditions)) {
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(key)) {
      throw new Error(`Invalid column name: ${key}`);
    }
    values.push(value);
    whereParts.push(`"${key}" = $${values.length}`);
  }

  let query = `SELECT ${safeColumns.join(', ')} FROM "${table}"`;
  if (whereParts.length > 0) {
    query += ` WHERE ${whereParts.join(' AND ')}`;
  }

  if (options?.orderBy) {
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(options.orderBy)) {
      throw new Error('Invalid orderBy column');
    }
    query += ` ORDER BY "${options.orderBy}" ${options.order || 'DESC'}`;
  }

  if (options?.limit) {
    values.push(Math.min(options.limit, 100)); // макс 100
    query += ` LIMIT $${values.length}`;
  }

  if (options?.offset) {
    values.push(options.offset);
    query += ` OFFSET $${values.length}`;
  }

  return { text: query, values };
}

/**
 * Безопасный построитель INSERT запросов
 */
export function safeInsert(
  table: string,
  data: Record<string, any>,
  returning?: string[]
): QueryConfig {
  if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(table)) {
    throw new Error('Invalid table name');
  }

  const columns: string[] = [];
  const placeholders: string[] = [];
  const values: any[] = [];

  for (const [key, value] of Object.entries(data)) {
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(key)) {
      throw new Error(`Invalid column name: ${key}`);
    }
    columns.push(`"${key}"`);
    values.push(value);
    placeholders.push(`$${values.length}`);
  }

  let query = `INSERT INTO "${table}" (${columns.join(', ')}) VALUES (${placeholders.join(', ')})`;

  if (returning?.length) {
    const safeCols = returning.map(r => {
      if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(r)) throw new Error(`Invalid column: ${r}`);
      return `"${r}"`;
    });
    query += ` RETURNING ${safeCols.join(', ')}`;
  }

  return { text: query, values };
}

/**
 * Безопасный построитель UPDATE запросов
 */
export function safeUpdate(
  table: string,
  data: Record<string, any>,
  conditions: Record<string, any>,
  returning?: string[]
): QueryConfig {
  if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(table)) {
    throw new Error('Invalid table name');
  }

  const values: any[] = [];
  const setParts: string[] = [];
  const whereParts: string[] = [];

  for (const [key, value] of Object.entries(data)) {
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(key)) {
      throw new Error(`Invalid column: ${key}`);
    }
    values.push(value);
    setParts.push(`"${key}" = $${values.length}`);
  }

  for (const [key, value] of Object.entries(conditions)) {
    if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(key)) {
      throw new Error(`Invalid column: ${key}`);
    }
    values.push(value);
    whereParts.push(`"${key}" = $${values.length}`);
  }

  if (whereParts.length === 0) {
    throw new Error('UPDATE without WHERE is not allowed');
  }

  let query = `UPDATE "${table}" SET ${setParts.join(', ')} WHERE ${whereParts.join(' AND ')}`;

  if (returning?.length) {
    const safeCols = returning.map(r => {
      if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(r)) throw new Error(`Invalid column: ${r}`);
      return `"${r}"`;
    });
    query += ` RETURNING ${safeCols.join(', ')}`;
  }

  return { text: query, values };
}

// ═══════════════════════════════════════════════════════════════════════════════
// 2. SUPABASE ROW LEVEL SECURITY — SQL миграции
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * SQL миграции для активации Row Level Security на всех таблицах
 * Выполнить через Supabase SQL Editor
 */
export const RLS_MIGRATIONS = `
-- ═══════════════════════════════════════════════════════════════════════════
-- ChefNet Invest — Row Level Security Policies
-- ═══════════════════════════════════════════════════════════════════════════

-- 1. Включаем RLS на всех пользовательских таблицах
ALTER TABLE IF EXISTS users ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS investments ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS audit_log ENABLE ROW LEVEL SECURITY;

-- 2. Политики для таблицы profiles
-- Пользователь видит только свой профиль
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  USING (auth.uid() = user_id);

-- Пользователь может редактировать только свой профиль
CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- 3. Политики для таблицы investments
-- Пользователь видит только свои инвестиции
CREATE POLICY "Users can view own investments"
  ON investments FOR SELECT
  USING (auth.uid() = user_id);

-- Пользователь может создавать инвестиции от своего имени
CREATE POLICY "Users can create own investments"
  ON investments FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Пользователь НЕ может удалять инвестиции
-- (только admin через service_role)

-- 4. Политики для таблицы documents (KYC документы)
CREATE POLICY "Users can view own documents"
  ON documents FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can upload own documents"
  ON documents FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- 5. Политики для notifications
CREATE POLICY "Users can view own notifications"
  ON notifications FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notifications"
  ON notifications FOR UPDATE
  USING (auth.uid() = user_id);

-- 6. Политики для referrals
CREATE POLICY "Users can view own referrals"
  ON referrals FOR SELECT
  USING (auth.uid() = referrer_id OR auth.uid() = referred_id);

-- 7. Audit log — только чтение для admin (через service_role)
CREATE POLICY "No direct access to audit log"
  ON audit_log FOR ALL
  USING (false); -- блокируем прямой доступ, только через service_role

-- 8. Admin доступ через custom claim
-- Добавить в Supabase: Authentication → Policies
CREATE POLICY "Admins can view all profiles"
  ON profiles FOR SELECT
  USING (
    auth.uid() IN (
      SELECT user_id FROM user_roles WHERE role = 'admin'
    )
  );

CREATE POLICY "Admins can view all investments"
  ON investments FOR SELECT
  USING (
    auth.uid() IN (
      SELECT user_id FROM user_roles WHERE role = 'admin'
    )
  );
`;

// ═══════════════════════════════════════════════════════════════════════════════
// 3. AUDIT LOG — Логирование всех действий
// ═══════════════════════════════════════════════════════════════════════════════

export const AUDIT_TABLE_MIGRATION = `
-- Таблица аудита всех действий
CREATE TABLE IF NOT EXISTS audit_log (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  action VARCHAR(100) NOT NULL,
  resource_type VARCHAR(100),
  resource_id UUID,
  details JSONB DEFAULT '{}',
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Индексы для быстрого поиска
CREATE INDEX IF NOT EXISTS idx_audit_user_id ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_log(action);
CREATE INDEX IF NOT EXISTS idx_audit_created_at ON audit_log(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_resource ON audit_log(resource_type, resource_id);

-- Автоматическая очистка записей старше 90 дней
CREATE OR REPLACE FUNCTION cleanup_old_audit_logs()
RETURNS void AS $$
BEGIN
  DELETE FROM audit_log WHERE created_at < NOW() - INTERVAL '90 days';
END;
$$ LANGUAGE plpgsql;
`;

/**
 * Запись в аудит-лог
 */
export async function logAuditEvent(
  db: any, // pg Pool instance
  event: {
    userId?: string;
    action: string;
    resourceType?: string;
    resourceId?: string;
    details?: Record<string, any>;
    ip?: string;
    userAgent?: string;
  }
) {
  try {
    await db.query(
      `INSERT INTO audit_log (user_id, action, resource_type, resource_id, details, ip_address, user_agent)
       VALUES ($1, $2, $3, $4, $5, $6::inet, $7)`,
      [
        event.userId || null,
        event.action,
        event.resourceType || null,
        event.resourceId || null,
        JSON.stringify(event.details || {}),
        event.ip || null,
        event.userAgent || null,
      ]
    );
  } catch (error) {
    console.error('[AUDIT] Failed to log event:', error);
    // Не бросаем ошибку — аудит не должен ломать основную логику
  }
}
